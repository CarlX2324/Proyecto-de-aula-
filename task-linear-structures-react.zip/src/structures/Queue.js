class QNode { constructor(value){ this.value=value; this.next=null } }
export default class Queue {
  constructor(){ this.head=null; this.tail=null; this.size=0 }
  clear(){ this.head=null; this.tail=null; this.size=0 }
  enqueue(value){ const n=new QNode(value); if(!this.tail){ this.head=n; this.tail=n } else { this.tail.next=n; this.tail=n } this.size++ }
  dequeue(){ if(!this.head) return null; const v=this.head.value; this.head=this.head.next; if(!this.head) this.tail=null; this.size--; return v }
  front(){ return this.head?this.head.value:null }
  rear(){ return this.tail?this.tail.value:null }
  isEmpty(){ return this.size===0 }
  toArray(){ const out=[]; let cur=this.head; while(cur){ out.push(cur.value); cur=cur.next } return out }
}
