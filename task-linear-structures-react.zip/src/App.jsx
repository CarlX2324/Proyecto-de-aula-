import React, { useEffect, useState } from 'react'
import Header from './components/Header'
import Sidebar from './components/Sidebar'
import TaskListView from './components/TaskListView'
import TaskFormModal from './components/TaskFormModal'
import ConfirmModal from './components/ConfirmModal'
import Footer from './components/Footer'
import { DoublyLinkedList } from './structures/DoublyLinkedList'
import Stack from './structures/Stack'
import Queue from './structures/Queue'
import { loadAll, saveAll, exportTasksCSV } from './utils/storage'
import dayjs from 'dayjs'

const STORAGE_KEY = 'task_linear_data_v1'

const initial = loadAll(STORAGE_KEY) || {
  list: [],
  stack: [],
  queue: []
}

function App(){
  const [mode, setMode] = useState('list')
  const [tasks, setTasks] = useState(initial)
  const [showForm, setShowForm] = useState(false)
  const [editTask, setEditTask] = useState(null)
  const [confirm, setConfirm] = useState({open:false, action:null, payload:null})
  const [theme, setTheme] = useState('light')
  const [search, setSearch] = useState('')
  const [filterPriority, setFilterPriority] = useState('all')
  const [sortBy, setSortBy] = useState('createdDesc')

  const listStruct = React.useRef(new DoublyLinkedList())
  const stackStruct = React.useRef(new Stack())
  const queueStruct = React.useRef(new Queue())

  useEffect(()=>{
    listStruct.current.clear()
    stackStruct.current.clear()
    queueStruct.current.clear()
    tasks.list.forEach(t => listStruct.current.append(t))
    tasks.stack.forEach(t => stackStruct.current.push(t))
    tasks.queue.forEach(t => queueStruct.current.enqueue(t))
    document.documentElement.setAttribute('data-theme', theme)
  }, [])

  useEffect(()=>{
    saveAll(STORAGE_KEY, tasks)
  }, [tasks])

  const openCreate = () => {
    setEditTask(null)
    setShowForm(true)
  }

  const saveTask = (task, target) => {
    const t = {...task, id: task.id || `${Date.now()}_${Math.random().toString(36).slice(2,9)}`, createdAt: task.createdAt || dayjs().toISOString()}
    if(target === 'list'){
      listStruct.current.append(t)
      setTasks(prev => ({...prev, list: listStruct.current.toArray()}))
    } else if(target === 'stack'){
      stackStruct.current.push(t)
      setTasks(prev => ({...prev, stack: stackStruct.current.toArray()}))
    } else {
      queueStruct.current.enqueue(t)
      setTasks(prev => ({...prev, queue: queueStruct.current.toArray()}))
    }
    setShowForm(false)
  }

  const updateTask = (task, target) => {
    const updater = arr => arr.map(a => a.id === task.id ? {...a,...task} : a)
    if(target==='list') setTasks(prev=>({...prev, list: updater(prev.list)}))
    if(target==='stack') setTasks(prev=>({...prev, stack: updater(prev.stack)}))
    if(target==='queue') setTasks(prev=>({...prev, queue: updater(prev.queue)}))
    setShowForm(false)
  }

  const deleteTask = (id, target) => {
    const remover = arr => arr.filter(a=>a.id !== id)
    if(target==='list') setTasks(prev=>({...prev, list: remover(prev.list)}))
    if(target==='stack') setTasks(prev=>({...prev, stack: remover(prev.stack)}))
    if(target==='queue') setTasks(prev=>({...prev, queue: remover(prev.queue)}))
    setConfirm({open:false, action:null, payload:null})
  }

  const clearAllTarget = (target) => {
    if(target==='list') setTasks(prev=>({...prev, list: []}))
    if(target==='stack') setTasks(prev=>({...prev, stack: []}))
    if(target==='queue') setTasks(prev=>({...prev, queue: []}))
    setConfirm({open:false})
  }

  const filteredSorted = (arr) => {
    let res = arr.slice()
    if(search) res = res.filter(t => (t.title||'').toLowerCase().includes(search.toLowerCase()) || (t.description||'').toLowerCase().includes(search.toLowerCase()))
    if(filterPriority !== 'all') res = res.filter(t => t.priority === filterPriority)
    if(sortBy === 'dateAsc') res.sort((a,b)=> new Date(a.due || a.createdAt) - new Date(b.due || b.createdAt))
    else if(sortBy === 'dateDesc') res.sort((a,b)=> new Date(b.due || b.createdAt) - new Date(a.due || a.createdAt))
    else if(sortBy === 'priority') res.sort((a,b)=> (b.priorityRank || 0) - (a.priorityRank || 0))
    else res.sort((a,b)=> new Date(b.createdAt) - new Date(a.createdAt))
    return res
  }

  const exportCSV = (target) => {
    const arr = tasks[target] || []
    exportTasksCSV(arr, `${target}_tasks_export.csv`)
  }

  return (
    <div className="app-shell">
      <Header
        onExport={()=>exportCSV(mode)}
        onToggleTheme={()=>setTheme(t=> t==='light' ? 'dark' : 'light')}
        theme={theme}
        search={search}
        setSearch={setSearch}
      />
      <div className="main-grid">
        <Sidebar
          mode={mode}
          setMode={setMode}
          openCreate={openCreate}
          tasksCount={{list: tasks.list.length, stack: tasks.stack.length, queue: tasks.queue.length}}
        />
        <main>
          <TaskListView
            mode={mode}
            tasks={filteredSorted(tasks[mode])}
            onEdit={(t)=>{ setEditTask(t); setShowForm(true); }}
            onDelete={(t)=> setConfirm({open:true, action:'delete', payload:{id:t.id, target:mode}})}
            onClear={()=> setConfirm({open:true, action:'clear', payload:{target:mode}})}
            setFilterPriority={setFilterPriority}
            setSortBy={setSortBy}
            sortBy={sortBy}
            filterPriority={filterPriority}
            exportCSV={()=>exportCSV(mode)}
          />
        </main>
      </div>

      <Footer />

      {showForm && <TaskFormModal
        mode={mode}
        onClose={()=>setShowForm(false)}
        onSave={(task)=> editTask ? updateTask(task, mode) : saveTask(task, mode)}
        existing={editTask}
      />}

      {confirm.open && <ConfirmModal
        message={ confirm.action === 'delete' ? '¿Eliminar esta tarea?' : '¿Limpiar todas las tareas de esta estructura?'}
        onCancel={()=>setConfirm({open:false})}
        onConfirm={()=>{
          if(confirm.action === 'delete'){
            deleteTask(confirm.payload.id, confirm.payload.target)
          } else {
            clearAllTarget(confirm.payload.target)
          }
        }}
      />}
    </div>
  )
}

export default App
