import React from 'react'
export default function TaskListView({mode,tasks,onEdit,onDelete,onClear,setFilterPriority,setSortBy,sortBy,filterPriority,exportCSV}){
  return (<div><h2>{mode.toUpperCase()}</h2><div>{tasks.length===0 ? <div>No hay tareas.</div> : tasks.map(t=> (<div key={t.id}><strong>{t.title}</strong><div>{t.description}</div><div><button onClick={()=>onEdit(t)}>Editar</button><button onClick={()=>onDelete(t)}>Eliminar</button></div></div>))}</div></div>)
}
