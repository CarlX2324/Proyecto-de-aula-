# Sistema de Gestión de Tareas — Estructuras Lineales (React + Vite)

Proyecto: aplicación web que implementa **Lista (doblemente enlazada)**, **Pila** y **Cola** para gestionar tareas.  

## Características
- CRUD de tareas (crear, leer, editar, eliminar)
- Tres modos: **Lista**, **Pila**, **Cola**
- Estructuras implementadas manualmente en `src/structures/`
- Búsqueda, filtros por prioridad y ordenamiento
- Persistencia en **LocalStorage**
- Exportar tareas a CSV
- Tema claro / oscuro
- Listo para servir en GitHub Pages o cualquier hosting estático

## Requisitos
- Node.js (>=18 recomendado)
- npm

## Instalación (local)
```bash
git clone <tu-repo>
cd task-linear-structures-react
npm install
npm run dev
# Abre http://localhost:5173
```
