export class DoublyLinkedNode { constructor(value){ this.value = value; this.prev = null; this.next = null } }
export class DoublyLinkedList {
  constructor(){ this.head = null; this.tail = null; this.length = 0 }
  clear(){ this.head = null; this.tail = null; this.length = 0 }
  append(value){ const node = new DoublyLinkedNode(value); if(!this.head){ this.head = node; this.tail = node } else { this.tail.next = node; node.prev = this.tail; this.tail = node } this.length++ }
  prepend(value){ const node = new DoublyLinkedNode(value); if(!this.head){ this.head = node; this.tail = node } else { this.head.prev = node; node.next = this.head; this.head = node } this.length++ }
  removeByPosition(pos){ if(pos < 0 || pos >= this.length) return null; let current = this.head; let index=0; while(index<pos){ current = current.next; index++ } if(current.prev) current.prev.next = current.next; else this.head = current.next; if(current.next) current.next.prev = current.prev; else this.tail = current.prev; this.length--; return current.value }
  find(predicate){ let cur = this.head; while(cur){ if(predicate(cur.value)) return cur.value; cur = cur.next } return null }
  toArray(){ const out=[]; let cur = this.head; while(cur){ out.push(cur.value); cur = cur.next } return out }
}
