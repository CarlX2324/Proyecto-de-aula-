class Node { constructor(value,next=null){ this.value=value; this.next=next } }
export default class Stack {
  constructor(){ this.top=null; this.size=0 }
  clear(){ this.top=null; this.size=0 }
  push(value){ const n=new Node(value,this.top); this.top=n; this.size++ }
  pop(){ if(!this.top) return null; const v=this.top.value; this.top=this.top.next; this.size--; return v }
  peek(){ return this.top?this.top.value:null }
  isEmpty(){ return this.size===0 }
  toArray(){ const out=[]; let cur=this.top; while(cur){ out.push(cur.value); cur=cur.next } return out }
}
