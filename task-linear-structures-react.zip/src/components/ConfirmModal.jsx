import React from 'react'
export default function ConfirmModal({message,onCancel,onConfirm}){ return (<div className="modal"><div className="card"><h3>{message}</h3><div><button onClick={onCancel}>Cancelar</button><button onClick={onConfirm}>Confirmar</button></div></div></div>) }
